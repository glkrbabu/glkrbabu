package com.demo;

import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException; 
import java.sql.Statement; 

public class OrderServiceDAO {

	/**
	 * H2 DB connection DB  Details
	 *
	 */
	
	static final String JDBC_DRIVER = "org.h2.Driver";   
	static final String DB_URL = "jdbc:h2:~/WEB-INF/lib"; 
	static final String USER = "sa"; 
	static final String PASS = ""; 
	
	Connection conn = null; 
    Statement stmt = null; 
    
    
	/**
	 * retrieving Order  Details
	 *
	 */
	
	public OrderDetails retrievingOrderDetails(){ 
		
		OrderItemDetails x = new OrderItemDetails();
		OrderDetails od = new OrderDetails();
		
				try { 
				       
				       Class.forName(JDBC_DRIVER);  
				       conn = DriverManager.getConnection(DB_URL,USER,PASS);  
				       stmt = conn.createStatement(); 
				       String sql =  "SELECT CustName,OrderDate,ShippingAddress,total FROM OrderDetails";  
				       ResultSet rs =  stmt.executeUpdate(sql);
				       if(rs.getInt("total") equals(null)  {
				    	   OrderManagementExceptionHandlerClass OM = new OrderManagementExceptionHandlerClass();
				    	   OM.getExceptionCaseOrderDetails();
				       }else {
				  
				       while(rs.next()) { 
				    	   od.setCustomerName(rs.getString("CustName"));
				   		od.setOrderDate(rs.getString("OrderDate"));
				   		od.setShippingAddress(rs.getString("Shippingaddress"));
				   		od.setOrderItemDetails(x);
				   		  od.setTotal(rs.getInt("total"));
				       }
				       }
				       rs.close();
				       stmt.close(); 
				       conn.close(); 
				    } catch(SQLException se) { 
				       se.printStackTrace(); 
				    } catch(Exception e) {  
				       e.printStackTrace(); 
				    } finally {  
				       try{ 
				          if(stmt!=null) stmt.close(); 
				       } catch(SQLException se2) { 
				    	   se2.printStackTrace(); 
				       } 
				       try { 
				          if(conn!=null) conn.close(); 
				       } catch(SQLException se){ 
				          se.printStackTrace(); 
				       } 
				    } 		
				
				return od; 
	   } 
	   
	/**
	 * Adding Order  Details
	 *
	 */
	    
	   public OrderDetails insertingOrderDetails(OrderDetails od){ 
		   OrderDetails od2 = od;
					 
					String CustName = od.getCustomerName();
					String Orderdate = od.getOrderDate();
					String Orderdate = od.getShippingAddress();
					int total = od.getTotal();
					try { 
					       
					       Class.forName(JDBC_DRIVER);  
					       conn = DriverManager.getConnection(DB_URL,USER,PASS);  
					       stmt = conn.createStatement(); 
					       String sql =  "INSERT INTO OrderItemDetails " + " VALUES " + "("+ custName +"," + OrderDate+ "," + shippingAddress+ "," + total ")"  ";  
					       ResultSet rs =  stmt.executeUpdate(sql);		       
					       rs.close();
					       stmt.close(); 
					       conn.close(); 
					    } catch(SQLException se) { 
					       se.printStackTrace(); 
					    } catch(Exception e) {  
					       e.printStackTrace(); 
					    } finally {  
					       try{ 
					          if(stmt!=null) stmt.close(); 
					       } catch(SQLException se2) { 
					    	   se2.printStackTrace(); 
					       } 
					       try { 
					          if(conn!=null) conn.close(); 
					       } catch(SQLException se){ 
					          se.printStackTrace(); 
					       } 
					    } 		
					
					return od2; 
				   
				   
		   }

}

