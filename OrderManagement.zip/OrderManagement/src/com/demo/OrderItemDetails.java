package com.demo;

import javax.xml.bind.annotation.XmlElement;

public class OrderItemDetails {

	
	   private int Quantity; 
	   private String productCode; 
       private String productName;  
	   
       public OrderItemDetails(){} 
	    
	   public OrderItemDetails(int Quantity, String productCode, String productName){  
	      this.Quantity = Quantity; 
	      this.productName = productName; 
	      this.productCode = productCode; 
	   }  
	   public int getQuantity() { 
	      return Quantity; 
	   }  
	   @XmlElement 
	   public void setQuantity(int Quantity) { 
	      this.Quantity = Quantity; 
	   } 
	   public String getProductCode() {
		return productCode;
	}
    
	   @XmlElement 
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductName() {
		return productName;
	}
    
	@XmlElement 
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
}
