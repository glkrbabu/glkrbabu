package com.demo;

public class OrderManagementExceptionHandlerClass {
	
	public OrderDetails getExceptionCaseOrderDetails() {
		OrderDetails od = new OrderDetails();
		od.setCustomerName(null);
		od.setOrderDate(null);
		od.setShippingAddress("no orders in DB");
		od.setTotal(0);
	}
	
	public OrderDetails getExceptionCaseOrderItemsDetails() {
		OrderItemDetails od = new OrderItemDetails();
		od.setProductCode(null);
		od.setProductName(null);
		od.setQuantity(0);
	}

}
