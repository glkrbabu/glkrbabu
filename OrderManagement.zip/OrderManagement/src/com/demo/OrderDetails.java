package com.demo;

import java.util.Date;

public class OrderDetails {
	
	private int total; 
	private String customerName;
	private String shippingAddress;
	private String orderDate;
	private   OrderItemDetails orderItemDetails;
	
	public OrderDetails() {}
	
	public OrderDetails(int total, String customerName, String shippingAddress, String orderDate,
			OrderItemDetails orderItemDetails) {
		super();
		this.total = total;
		this.customerName = customerName;
		this.shippingAddress = shippingAddress;
		this.orderDate = orderDate;
		this.orderItemDetails = orderItemDetails;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String string) {
		this.orderDate = string;
	}
	public OrderItemDetails getOrderItemDetails() {
		return orderItemDetails;
	}
	public void setOrderItemDetails(OrderItemDetails orderItemDetails) {
		this.orderItemDetails = orderItemDetails;
	}
	
}
