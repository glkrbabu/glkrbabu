package com.demo;

import java.util.List; 
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path; 
import javax.ws.rs.Produces; 
import javax.ws.rs.core.MediaType;  

@Path("/OrderService") 
public class OrderService {	
	OrderServiceDAO orderServiceDao = new OrderServiceDAO();  

	   @GET 
	   @Path("/retrievingorders") 
	   @Produces(MediaType.APPLICATION_XML) 
	   public OrderDetails getOrderDetails(){ 
	      return orderServiceDao.retrievingOrderDetails(); 
	   } 
	   
	   @POST
	   @Path("/insertingorders")
	   @Produces(MediaType.APPLICATION_XML) 
	   public String putOrderDetails(OrderDetails od){ 
		      return ("inseted" + orderServiceDao.insertingOrderDetails(od)); 
		   }

	
}